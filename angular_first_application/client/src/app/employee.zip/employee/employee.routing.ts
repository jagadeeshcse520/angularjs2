import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
//import {AuthGuard} from '../login/auth-guard.service';
import {EmployeeListComponent} from './employeeList.component';
import {AddEmployeeComponent}  from './addEmployee.component';
import {EditEmployeeComponent} from './editEmployee.component';
import {EmployeeViewComponent} from './employeeView.component';

const employeeRoutes: Routes = [
  {path: 'employeeList', component: EmployeeListComponent},
  {path: 'addEmployee', component: AddEmployeeComponent},
  {path: 'editEmployee/:id', component: EditEmployeeComponent},
  {path: 'employeeView/:id', component: EmployeeViewComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(employeeRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class EmployeeRoutingModule {
}
