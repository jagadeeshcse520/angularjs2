import {Injectable} from "@angular/core";
import 'rxjs/Rx';
import { RequestOptions,Headers, Http, Response } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import {Config} from './../config/config';
import {EmployeeList} from "./employeelist";

@Injectable()
export class EmployeeService {
  constructor(public httpService: Http) {
  }
  public employeeObj:EmployeeList;
  getEmployeeList():Observable<any>{
    return this.httpService
      .get('http://localhost/test_project/index.php/api/Employee/employeeList')
      .map((response: Response) =>  response.json() as EmployeeList[])
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

  }

  postaddEmployee(subObj:any):Observable<any>{
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
    let options = new RequestOptions({ headers: headers });
    return this.httpService
      .post('http://localhost/test_project/index.php/api/Employee/insertEmployee',subObj,options)
      .map((response: Response) => response.json() as EmployeeList[] )
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }

  geteditEmployee(empId:any):Observable<any>{
    return this.httpService
      .get('http://localhost/test_project/index.php/api/Employee/getEmployee/'+empId)
      .map((response: Response) =>  response.json() as EmployeeList[])
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

  }

  posteditEmployee(subObj:any):Observable<any>{
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
    let options = new RequestOptions({ headers: headers });
    return this.httpService
      .post('http://localhost/test_project/index.php/api/Employee/editEmployee',subObj,options)
      .map((response: Response) => response.json() as EmployeeList[] )
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }

  posteditStatus(subObj:any):Observable<any>{
    let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
    let options = new RequestOptions({ headers: headers });
    return this.httpService
      .post('http://localhost/test_project/index.php/api/Employee/editStatus',subObj,options)
      .map((response: Response) => response.json() as EmployeeList[] )
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }


}
