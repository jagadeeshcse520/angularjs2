import {NgModule} from '@angular/core';
import {EmployeeRoutingModule} from "./employee.routing";

@NgModule({
  imports: [
    EmployeeRoutingModule
  ]
})

export class EmployeeModule {
}
