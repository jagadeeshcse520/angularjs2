export class EmployeeList{
    constructor(
        public emp_address?: any,
        public emp_email?: any,
        public emp_gender?: string,
        public emp_id?: any,
        public emp_image?: any,
        public emp_name?: string,
        public pwd?: any

    ){}
}
