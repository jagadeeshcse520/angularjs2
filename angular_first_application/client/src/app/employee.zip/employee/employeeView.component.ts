import {Component, OnInit, NgZone} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {EmployeeService} from "./employee-service";
import {EmployeeList} from "./employeelist";


@Component({
  moduleId: module.id,
  templateUrl: 'employeeView.component.html'
  //styleUrls: ['employee.css']
})


export class EmployeeViewComponent implements OnInit {
  constructor(public employeeservice: EmployeeService,
              public router: Router,public route: ActivatedRoute) {
  }
  public employeeListData: EmployeeList[]=[];
  public empID:any;

  ngOnInit() {
    let urlBase64Id = this.route.snapshot.params['id'];
    this.employeeservice.geteditEmployee(urlBase64Id).subscribe(response => {
      this.employeeListData = response[0];
      //alert(JSON.stringify(response));
    });
  }

}

