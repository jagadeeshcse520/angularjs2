import {Component, OnInit, NgZone, OnDestroy} from '@angular/core';
import * as moment from 'moment-timezone';
import {DatePipe} from "@angular/common";
import {Router, ActivatedRoute} from "@angular/router";
import {EmployeeList} from "./employeelist";
import {EmployeeService} from "./employee-service";
import * as _ from 'underscore';
import {Config} from "../config/config";


@Component({
  templateUrl: 'addEmployee.component.html'
  //'styleUrls: ['styles.css']
})

export class AddEmployeeComponent implements OnInit {
  constructor(public employeeService: EmployeeService,
              public router: Router) {


  }


  public employeeListData: EmployeeList ={};
  public jname:any;
  public errorMsg:any;
  public errcnt = [];
  public setAlert: boolean = false;
  public successAlert: boolean = false;
  public succcessMessage: any;
  public successStatus: any;

  ngOnInit() {

    }


  submitEmployee() {
    alert(this.employeeListData.emp_name);
    this.errcnt = [];
    if (!this.employeeListData.emp_name) {
      this.setAlert = true;
      this.errorMsg = "Please Enter Employee Name";
      this.errcnt.push(1);
      return;
    }
    if(!this.employeeListData.pwd) {
      this.setAlert = true;
      this.errorMsg = "Please Enter Employee  Password";
      this.errcnt.push(1);
      return;
    }
    if(!this.employeeListData.emp_email) {
      this.setAlert = true;
      this.errorMsg = "Please Enter Email ID";
      this.errcnt.push(1);
      return;
    }

    if(this.errcnt.length<=0)
    {
      this.employeeService.postaddEmployee(this.employeeListData).subscribe(response => {
        //alert(JSON.stringify(response.result));

        if(response.result=="Succesfully registered employee details") {
          this.successAlert = true;
          this.succcessMessage = response.result;
          this.successStatus = 1;
        }
        if(response.result=="Employee already exists") {
          this.successAlert = true;
          this.succcessMessage = response.result;
          this.successStatus = 0;
        }
      });
      //this.router.navigate(['/employeeList']);
    }

  }

  employeeList()
  {
    this.router.navigate(['/employeeList']);
  }

  closeAlertBox()
  {
    this.setAlert = false;
  }
  redirectLink(status:any) {
    if(status==1){
      this.successAlert = false;
      this.router.navigate(['/employeeList']);
    } else {
      this.successAlert = false;
    }


  }

}
